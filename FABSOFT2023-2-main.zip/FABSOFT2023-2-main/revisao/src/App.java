import entidades.Pessoa;

public class App {
    public static void main(String[] args) throws Exception {
        //System.out.println("Hello, World!");

        Pessoa pzezinho = new Pessoa();
        pzezinho.setNome("Zezinho");

        Pessoa pmaria = new Pessoa("Mariazinha");

        System.out.println(pzezinho);
        System.out.println(pmaria);

    }
}
