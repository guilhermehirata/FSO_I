package entidades;

public class Pessoa {
    private String nome;
    private int idade;
    private Cidade cidade;

    public String toString(){
        return getNome();
    }
    public Pessoa() {
        System.out.println("Construtor sem parametros");
    }
    public Pessoa(String nome) {
        System.out.println("Construtor com parametros");
        setNome(nome);
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }


}
